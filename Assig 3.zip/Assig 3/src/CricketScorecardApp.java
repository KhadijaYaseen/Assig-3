import java.util.Random;
import java.util.Scanner;

public class CricketScorecardApp {

    static final int MAX_OVERS = 20;
    static final int MAX_PLAYERS = 11;
    static final int MAX_BALLS = MAX_OVERS * 6;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Input team names
        System.out.print("Enter the name of Team 1: ");
        String team1 = scanner.nextLine();
        System.out.print("Enter the name of Team 2: ");
        String team2 = scanner.nextLine();

        // Toss simulation
        String tossWinner = (random.nextBoolean()) ? team1 : team2;
        String tossLoser = (tossWinner.equals(team1)) ? team2 : team1;
        System.out.println("Toss Winner: " + tossWinner);
        System.out.print(tossWinner + ", do you want to bat or bowl? (bat/bowl): ");
        String tossChoice = scanner.nextLine();

        boolean isTeam1BattingFirst = tossWinner.equals(team1) && tossChoice.equals("bat") || tossWinner.equals(team2) && tossChoice.equals("bowl");

        // Initialize players
        String[] team1Players = new String[MAX_PLAYERS];
        String[] team2Players = new String[MAX_PLAYERS];

        System.out.println("Enter names of players for " + team1 + ":");
        for (int i = 0; i < MAX_PLAYERS; i++) {
            System.out.print("Player " + (i + 1) + ": ");
            team1Players[i] = scanner.nextLine();
        }

        System.out.println("Enter names of players for " + team2 + ":");
        for (int i = 0; i < MAX_PLAYERS; i++) {
            System.out.print("Player " + (i + 1) + ": ");
            team2Players[i] = scanner.nextLine();
        }

        // Initialize scores
        TeamScore team1Score = new TeamScore();
        TeamScore team2Score = new TeamScore();

        // Simulate innings
        simulateInnings(scanner, random, team1Score, team1Players, team2Score, team2Players, isTeam1BattingFirst);

        // Display scorecards
        System.out.println("Scorecard for " + team1 + ":");
        displayScorecard(team1Score, team1Players);
        System.out.println("Total score: " + team1Score.totalRuns + "/" + team1Score.wickets + " in " + team1Score.oversBowled + " overs");

        System.out.println("Scorecard for " + team2 + ":");
        displayScorecard(team2Score, team2Players);
        System.out.println("Total score: " + team2Score.totalRuns + "/" + team2Score.wickets + " in " + team2Score.oversBowled + " overs");

        // Determine winner
        determineWinner(team1, team2, team1Score, team2Score);
    }

    private static void simulateInnings(Scanner scanner, Random random, TeamScore battingTeamScore, String[] battingTeamPlayers, TeamScore bowlingTeamScore, String[] bowlingTeamPlayers, boolean isFirstInnings) {
        int ballsBowled = 0;
        int currentBatsmanIndex = 0;
        int nextBatsmanIndex = 1;

        while (battingTeamScore.oversBowled < MAX_OVERS && ballsBowled < MAX_BALLS && battingTeamScore.wickets < MAX_PLAYERS) {
            int runs = random.nextInt(7); // Runs scored in this ball (0 to 6)
            boolean isWicket = random.nextBoolean(); // Wicket fall or not

            if (isWicket) {
                battingTeamScore.wickets++;
                battingTeamScore.players[currentBatsmanIndex].isOut = true;
                System.out.println(battingTeamPlayers[currentBatsmanIndex] + " is out!");
                currentBatsmanIndex = nextBatsmanIndex++;
                if (nextBatsmanIndex >= MAX_PLAYERS) break; // No more players left
            } else {
                battingTeamScore.players[currentBatsmanIndex].runs += runs;
                battingTeamScore.players[currentBatsmanIndex].ballsFaced++;
                battingTeamScore.totalRuns += runs;
            }

            ballsBowled++;
            if (ballsBowled % 6 == 0) battingTeamScore.oversBowled++;
        }
    }

    private static void displayScorecard(TeamScore teamScore, String[] teamPlayers) {
        System.out.printf("%-15s %-5s %-4s %-10s %-10s%n", "Name", "Score", "Out", "Balls", "Strike Rate");
        for (int i = 0; i < MAX_PLAYERS; i++) {
            Batsman batsman = teamScore.players[i];
            System.out.printf("%-15s %-5d %-4s %-10d %-10.2f%n",
                    teamPlayers[i],
                    batsman.runs,
                    batsman.isOut ? "Out" : "Not Out",
                    batsman.ballsFaced,
                    batsman.ballsFaced == 0 ? 0 : (batsman.runs * 100.0 / batsman.ballsFaced));
        }
    }

    private static void determineWinner(String team1, String team2, TeamScore team1Score, TeamScore team2Score) {
        if (team1Score.totalRuns > team2Score.totalRuns) {
            System.out.println("Winner: " + team1);
        } else if (team2Score.totalRuns > team1Score.totalRuns) {
            System.out.println("Winner: " + team2);
        } else {
            System.out.println("The match is a tie.");
        }
    }

    static class Batsman {
        int runs;
        int ballsFaced;
        boolean isOut;

        Batsman() {
            this.runs = 0;
            this.ballsFaced = 0;
            this.isOut = false;
        }
    }

    static class TeamScore {
        int totalRuns;
        int wickets;
        int oversBowled;
        Batsman[] players;

        TeamScore() {
            this.totalRuns = 0;
            this.wickets = 0;
            this.oversBowled = 0;
            this.players = new Batsman[MAX_PLAYERS];
            for (int i = 0; i < MAX_PLAYERS; i++) {
                this.players[i] = new Batsman();
            }
        }
    }
}
